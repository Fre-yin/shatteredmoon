﻿namespace MareSynchronos.API.Dto.CharaData;

public enum ShareTypeDto
{
    Private,
    Shared
}
