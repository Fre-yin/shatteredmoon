﻿namespace MareSynchronos.API.Dto.CharaData;

public enum AccessTypeDto
{
    Individuals,
    ClosePairs,
    AllPairs,
    Public
}
