﻿namespace MareSynchronos.API.Data;

public class Constants
{
    public const string IndividualKeyword = "//MARE//DIRECT";
}