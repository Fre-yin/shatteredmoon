﻿namespace MareSynchronos.API.Data.Enum;

public enum MessageSeverity
{
    Information,
    Warning,
    Error
}