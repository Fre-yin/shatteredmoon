﻿namespace MareSynchronos.API.Data.Enum;

public enum IndividualPairStatus
{
    None,
    OneSided,
    Bidirectional
}