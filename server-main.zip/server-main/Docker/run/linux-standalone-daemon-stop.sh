#!/bin/sh
docker compose -f compose/mare-standalone.yml -p standalone stop