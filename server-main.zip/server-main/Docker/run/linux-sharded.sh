#!/bin/sh
docker compose -f compose/mare-sharded.yml -p sharded up