﻿using Microsoft.AspNetCore.Authorization;

namespace MareSynchronosShared.RequirementHandlers;

public class ValidTokenRequirement : IAuthorizationRequirement { }